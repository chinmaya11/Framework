package test;

import java.io.FileInputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import utility.ExcelUtils;
import utility.Log;
import utility.JDBCConnection;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import Config.ActionKeywords;
import Config.Constants;

public class TestNgProserviceOnCloud {
	
	public static Method method[];
    public static String sAction = null;
    public static String sObject = null;
    public static String sData = null;
    public static Properties OR;
    public static Properties CONFIG;

    public static int iTestStep;
    public static int iTestCases;
    public static int iTestLastStep;
    public static String sTestCaseID;
    public static String sTestCaseIDModule;
    public static String sDescription;
    public static String sDescriptionModule;
    public static String sRunMode;
    public static String sRunModeModule;
    public static String Col_TestStepDesc;

    public static String sTestCaseStepID;
    public static String sTestCaseModuleID;

    public static int iTotalTestCasesModules;
    public static String fileExtn = ".xlsx";
    public static int iTotalTestCases;
    public static int rows;
    public static int i;
    public static int j;
    public static int k;
    public static int l;
    public static String item;
    public static String sModuleName;
    //public static ArrayList<String> sheetModuleData = new ArrayList<String>();

    public static ExtentReports extent;
    public static ExtentTest test;

    static {
        Calendar calender = Calendar.getInstance();
        SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
        extent = new ExtentReports(System.getProperty("user.dir") + "/src/main/resources/resultEngine/test" + formater.format(calender.getTime()) + ".html", false);
    }

    public void getResult(ITestResult result) {
        if (result.getStatus() == ITestResult.SUCCESS) {
            test.log(LogStatus.PASS, result.getName() + "test is pass");
        } else if (result.getStatus() == ITestResult.SKIP) {
            test.log(LogStatus.SKIP, result.getName() + "test is skipped and skip reason is :-" + result.getThrowable());
        } else if (result.getStatus() == ITestResult.FAILURE) {
            test.log(LogStatus.ERROR, result.getName() + "test is failed :-" + result.getThrowable());
        } else if (result.getStatus() == ITestResult.STARTED) {
            test.log(LogStatus.INFO, result.getName() + "test is started");
        }
    }

    @AfterMethod()
    public void afterMethod(ITestResult result) {
        getResult(result);
    }

    @BeforeMethod()
    public void beforeMethod(Method result) {
        test = extent.startTest(result.getName());
        test.log(LogStatus.INFO, result.getName() + "test started");
    }

    @AfterClass(alwaysRun = true)
    public void endTest() {
        extent.endTest(test);
        extent.flush();
    }
    
    public TestNgProserviceOnCloud() {
    }
    
    public static void main(String[] args) throws Exception {

        DOMConfigurator.configure("log4j.xml");

        //start try code
        System.out.println("----------------Automation Run Started!!!----------------");
        Log.info("----------------Automation Run Started!!!----------------");

        //For JDBC connection
        //JDBCConnection.getDbConnection();
        //JDBCConnection.getPostGressDbConn();

        //TestReport();
        String[] valueToWrite = {"Mr. E", "Noida"};
        //Create an object of current class
        ExcelUtils objExcelFile = new ExcelUtils();
        //Write the file using file name, sheet name and the data to be filled
        objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWrite);


        FileInputStream fis = new FileInputStream(Constants.Path_OR);
        OR = new Properties(System.getProperties());
        OR.load(fis);

        FileInputStream fis2 = new FileInputStream(Constants.Path_CONFIG);
        CONFIG = new Properties(System.getProperties());
        CONFIG.load(fis2);

        //My code 08-07-2017
        String TestSuite = Constants.Path_TestDataModule;
        ExcelUtils.setExcelFile(TestSuite);
        System.out.println("Test Suite Name is : " + TestSuite);

        iTotalTestCasesModules = ExcelUtils.getRowCount(Constants.Sheet_TestCasesModules);
        System.out.println("Total Test Cases Modules : " + (iTotalTestCasesModules - 1));
        //public static ArrayList<String> sheetModuleData = new ArrayList<String>();

        ArrayList<String> sheetModuleData = new ArrayList<String>();

        for (l = 1; l < iTotalTestCasesModules; l++) {
            System.out.println("L value is : " + l + " and iTotalTestCasesModules is :" + iTotalTestCasesModules);


            System.out.println("Step Executing Times : " + l);

            String TestSuite1 = Constants.Path_TestDataModule;
            ExcelUtils.setExcelFile(TestSuite1);
            //System.out.println("NEW Test Suite Name is : "+TestSuite1);
            //iTotalTestCasesModules = ExcelUtils.getRowCount(Constants.Sheet_TestCasesModules);

            sModuleName = ExcelUtils.getCellData(l, Constants.Col_TestCaseIDModule, Constants.Sheet_TestCasesModules);


//		sheetModuleData.add(sModuleName);

            String sPath = (Constants.Path_TestData1) + sModuleName + fileExtn;
            RunModule(sPath);

            //String sFile= sheetModuleData.get(0);
            //System.out.println("Module File Name Is : "+sFile);


        }
//		for (String item : sheetModuleData) {
//			System.out.println("Module Name "+l+ " : " +item);
//			String sPath=(Constants.Path_TestData1)+item+fileExtn;
//			RunModule(sPath);
//			}
    } //end of main

    //Required later for reporting part
    /*public static void TestReport() throws Exception{
		Xl.generateReport("Constants.Path_TestData1","report.xlsx");
		System.out.println("Test Report");
	}*/


    public static void RunModule(String modulePath) throws Exception {

        System.out.println("Run Module Start for module_name : "+sModuleName);


        if (modulePath != null) {
            System.out.println("Path is : " + modulePath);
            //int iTotalTestCasesModules1 = ExcelUtils.getRowCount(Constants.Sheet_TestCasesModules);

		/*String TestSuite = Constants.Path_TestDataModule;
		ExcelUtils.setExcelFile(TestSuite);
		iTotalTestCasesModules = ExcelUtils.getRowCount(Constants.Sheet_TestCasesModules);*/

            for (k = 1; k < iTotalTestCasesModules; k++) {
			/*String sPath=(Constants.Path_TestData1)+modulePath+fileExtn;
			if (sPath != null) {
			System.out.println("Path is : "+sPath);*/
                //ExcelUtils.setExcelFile(sPath);

                ExcelUtils.setExcelFile(Constants.Path_TestDataModule);

                System.out.println("K value is : " + k + " and iTotalTestCasesModules is :" + iTotalTestCasesModules);
                sTestCaseIDModule = ExcelUtils.getCellData(k, Constants.Col_TestCaseIDModule, Constants.Sheet_TestCasesModules);
                System.out.println("Executing Test Module_ID : " + sTestCaseIDModule);
                sRunModeModule = ExcelUtils.getCellData(k, Constants.Col_RunmodeModule, Constants.Sheet_TestCasesModules);
                sDescriptionModule = ExcelUtils.getCellData(k, Constants.Col_TestModuleDesc, Constants.Sheet_TestCasesModules);
//			System.out.println("Executing Test Module : " + sTestCaseIDModule);
//			System.out.println("Test Module Description : " + sDescriptionModule);
                if (sRunModeModule.equalsIgnoreCase("yes")) {
                    //String datafile = Constants.Path_TestData;
                    ExcelUtils.setExcelFile(modulePath);

                    iTestCases = ExcelUtils.getRowContains(sTestCaseIDModule, Constants.Col_TestCaseIDModule, Constants.Sheet_TestCases);
                    System.out.println("iTestCases value is : " + iTestCases);

                    iTotalTestCases = ExcelUtils.getRowCount(Constants.Sheet_TestCases);
                    System.out.println("Total Number Of Test Cases : " + (iTotalTestCases - 1));

                    System.out.println("Executing Test Module_ID : " + sTestCaseIDModule);
                    System.out.println("Test Module Description : " + sDescriptionModule);

                    //1
                    for (j = iTestCases; j < iTotalTestCases; j++) {
                        sTestCaseModuleID = ExcelUtils.getCellData(j, Constants.Col_TestCaseIDModule, Constants.Sheet_TestCases);
//					sTestCaseID = ExcelUtils.getCellData(j, Constants.Col_TestCaseID, Constants.Sheet_TestCases);
                        sRunMode = ExcelUtils.getCellData(j, Constants.Col_Runmode, Constants.Sheet_TestCases);
                        sDescription = ExcelUtils.getCellData(j, Constants.Col_TestCaseDesc, Constants.Sheet_TestCases);
//					System.out.println("Executing Test CaseID : " + sTestCaseID);
//					System.out.println("Test CaseID Description : " + sDescription);

                        if (sTestCaseModuleID.equals(sTestCaseIDModule) && sRunMode.equalsIgnoreCase("yes")) {
                            sTestCaseID = ExcelUtils.getCellData(j, Constants.Col_TestCaseID, Constants.Sheet_TestCases);

                            System.out.println("Executing Test CaseID : " + sTestCaseID);
                            System.out.println("Test CaseID Description : " + sDescription);
                            Log.info("Automation Test Cases Run Started For Testcases_ID :" + sTestCaseID);

                            iTestStep = ExcelUtils.getRowContains(sTestCaseID, Constants.Col_TestCaseID, Constants.Sheet_TestSteps);
                            System.out.println("iTestStep value is : " + iTestStep);


                            rows = ExcelUtils.getRowCount(Constants.Sheet_TestSteps);
                            System.out.println("Total Number Of Rows = " + rows);

                            Log.info("Automation Test Step Run Started For Testcases_ID :" + sTestCaseID);

                            //0
                            for (i = iTestStep; i <= rows; i++) {

                                if (sTestCaseID.equals(ExcelUtils.getCellData(i, Constants.Col_TestCaseID, Constants.Sheet_TestSteps))) {
                                    sTestCaseStepID = ExcelUtils.getCellData(i, Constants.Col_TestCaseID, Constants.Sheet_TestSteps);
                                    System.out.println("Executing Row = " + i);
                                    System.out.println("Executing Test Case ID :" + sTestCaseStepID);
                                    System.out.println("Executing Test Scenario Step ID :" + ExcelUtils.getCellData(i, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps));
                                    System.out.println("Executing Test Scenario Description :" + "'" + ExcelUtils.getCellData(i, Constants.Col_TestStepDesc, Constants.Sheet_TestSteps) + "'");
                                    sAction = ExcelUtils.getCellData(i, Constants.Col_ActionKeyword, Constants.Sheet_TestSteps);
                                    sObject = ExcelUtils.getCellData(i, Constants.Col_ObjectKeyword, Constants.Sheet_TestSteps);
                                    sData = ExcelUtils.getCellData(i, Constants.Col_DataKeyword, Constants.Sheet_TestSteps);
                                    execute_actions();
                                } else {
                                    System.out.println("Automation Test Step Run Ended For Testcases_ID :" + sTestCaseStepID + " Successfully");
                                    Log.info("Automation Test Step Run Ended For Testcases_ID :" + sTestCaseStepID);
                                    break;
                                }
                            }
                            
                        } else if (sRunMode.equalsIgnoreCase("no")) {
                        //} else {
                            System.out.println("Automation Test Cases Run Ended For Testcases_ID :" + sTestCaseID + " Successfully");
                            Log.info("Automation Test Cases Run Ended For Testcases_ID :" + sTestCaseID);
                            //break; //do not uncomment need to check later
                        }
                    }
                    
                    System.out.println("----------$$$$$$$$$$$$$$$$$$$----------");
                    //1
                    
                } else if(sRunModeModule.equalsIgnoreCase("no") ) {
               // } else {
                    System.out.println("Automation Run Ended!!!");
                    Log.info("Automation Run Ended Successfully!!!");
                    break; //do not uncomment need to check later
                }
            }
        }
    }


    public static void execute_actions() throws Exception {

        if (sAction.equals("open")) {
            ActionKeywords.open(sObject, sData);
            Log.info("Opening browser : " + sData);
        } else if (sAction.equals("selectBrowser")) {
            ActionKeywords.selectBrowser(sObject, sData);
            Log.info("Select and Open browser : " + sData);
        } else if (sAction.equals("openBrowser")) {
            ActionKeywords.openBrowser(sObject, sData);
            Log.info("Open browser : " + sData);
        } else if (sAction.equals("navigate")) {
            ActionKeywords.navigate(sObject, sData);
            Log.info("Launching URl : " + sData);
        } else if (sAction.equals("click")) {
            ActionKeywords.click(sObject, sData);
            Log.info("Clicking on Object :" + sObject);
        } else if (sAction.equals("type")) {
            ActionKeywords.type(sObject, sData);
            Log.info("Typeing Data into input fields :" + sObject + " and data : " + sData);
        } else if (sAction.equals("waitFor")) {
            ActionKeywords.waitFor(sObject, sData);
            Log.info("Wait for :" + sData + " sec ");
        } else if (sAction.equals("close")) {
            ActionKeywords.close(sObject, sData);
            Log.info("Closing Browser" + sData);
        } else if (sAction.equals("quit")) {
            ActionKeywords.quit(sObject, sData);
            Log.info("Closing All Windows");
        } else if (sAction.equals("openIEBrowser")) {
            ActionKeywords.openIEBrowser(sObject, sData);
        } else if (sAction.equals("selectDropDown")) {
            ActionKeywords.selectDropDown(sObject, sData);
            Log.info("Select From Dropdown : " + sObject + " and data : " + sData);
        } else if (sAction.equals("enterData")) {
            ActionKeywords.enterData(sObject, sData);
            Log.info("Entering Data into input fields :" + sObject + " and data : " + sData);
        } else if (sAction.equals("selectCheckBox")) {
            ActionKeywords.selectCheckBox(sObject, sData);
            Log.info("Selecting check Box fields :" + sObject);
        } else if (sAction.equals("popUpAccept")) {
            ActionKeywords.popUpAccept(sObject, sData);
            Log.info("Handling Pop-up Accept");
        } else if (sAction.equals("popUpDismiss")) {
            ActionKeywords.popUpDismiss(sObject, sData);
            Log.info("Handling Pop-up Dismiss");
        } else if (sAction.equals("DatabaseConn")) {
            ActionKeywords.DatabaseConn(sObject, sData);
            Log.info("Connecting Database");
        }
    }

}
