package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class AssertionsScripts {
	
	@Test
	public static void testAssert1() {
		System.out.println("HURRY TEST testAssert1 Start");
		Assert.assertEquals("Chinmaya", "Chinmaya", "Actaul & Expected are not matched");
		System.out.println("HURRY TEST testAssert1 Complete");
	}
	
	@Test
	public static void testAssert2() {
		
		SoftAssert assertion = new SoftAssert();
		System.out.println("HURRY TEST testAssert2 Start");
		assertion.assertEquals("Chinmaya", "Chinmaya", "Actaul & Expected are not matched");		
		System.out.println("HURRY TEST testAssert2 Complete");
		assertion.assertAll();
	}
	
	
	
	private enum ElementStatus{
        VISIBLE,
        NOTVISIBLE,
        ENABLED,
        NOTENABLED,
        PRESENT,
        NOTPRESENT
    }
	@Test
    private ElementStatus isElementVisible(WebDriver driver, By by,ElementStatus getStatus){
        try{
            if(getStatus.equals(ElementStatus.ENABLED)){
                if(driver.findElement(by).isEnabled())
                    return ElementStatus.ENABLED;
                return ElementStatus.NOTENABLED; 
            }
            if(getStatus.equals(ElementStatus.VISIBLE)){
                if(driver.findElement(by).isDisplayed())
                    return ElementStatus.VISIBLE;
                return ElementStatus.NOTVISIBLE;
            }
            return ElementStatus.PRESENT;
        }catch(org.openqa.selenium.NoSuchElementException nse){
            return ElementStatus.NOTPRESENT;
        }
    }
	

}
