package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Config.Constants;

public class ExcelUtils {

	public static XSSFSheet ExcelWSheet;
	public static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;
	public static FormulaEvaluator objFormulaEvaluator;
	public static DataFormatter objDefaultFormat;
	//public static String testFileName = "TestReport.xlsx";

	public static void setExcelFile(String Path) throws Exception {
		FileInputStream ExcelFile = new FileInputStream(Path);
		ExcelWBook = new XSSFWorkbook(ExcelFile);

		objFormulaEvaluator = new XSSFFormulaEvaluator(ExcelWBook);
		objDefaultFormat = new DataFormatter();

	}

	public static String getCellData(int RowNum, int ColNum, String SheetName)
			throws Exception {

		ExcelWSheet = ExcelWBook.getSheet(SheetName);

		try{
			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
			String CellData = Cell.getStringCellValue();
			return CellData;
		}catch (Exception e){
			return"";
		}



	}

	public static int getRowCount(String SheetName) {
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
		return ExcelWSheet.getLastRowNum() + 1;

	}

	public static int getRowContains(String sTestCaseName, int colNum,
									 String SheetName) throws Exception {
		int i;
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
		int rowCount = ExcelUtils.getRowCount(SheetName);
		for (i = 0; i < rowCount; i++) {
			if (ExcelUtils.getCellData(i, colNum, SheetName).equalsIgnoreCase(
					sTestCaseName)) {
				System.out.println("i = " + i + " , rowCount = " + rowCount
						+ " , sTestCaseName = " + sTestCaseName);
				break;
			}
		}
		return i;
	}

	public static void writeExcel(String filePath,String fileName,String SheetName,String[] dataToWrite) throws IOException {

		//Create an object of File class to open xlsx file
		File file =    new File(filePath+"\\"+fileName);
		System.out.println("file path is : "+filePath+" and fileName is : "+fileName);
		System.out.println("file location is : "+file);

		FileInputStream ExcelFile = new FileInputStream(file);
		System.out.println("excelFile name is : "+ExcelFile);

		ExcelWBook = new XSSFWorkbook(ExcelFile);
		System.out.println("ExcelWBook name is : "+ExcelWBook);

//		objFormulaEvaluator = new XSSFFormulaEvaluator(ExcelWBook);
//		objDefaultFormat = new DataFormatter();

		//Read excel sheet by sheet name
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
		System.out.println("Excel sheet name is : "+ExcelWSheet);

		//Get the current count of rows in excel file
		int rowCount = ExcelWSheet.getLastRowNum()-ExcelWSheet.getFirstRowNum();
		System.out.println("rowCount is : "+rowCount);



		//Get the first row from the sheet
		Row row = ExcelWSheet.getRow(0);
		System.out.println("row is : "+row);

		//Create a new row and append it at last of sheet
		Row newRow = ExcelWSheet.createRow(rowCount+1);

		for(int j = 0; j < row.getLastCellNum(); j++){

			//Fill data in row

			Cell = (XSSFCell) newRow.createCell(j);
			Cell.setCellValue(dataToWrite[j]);

			
			//Close input stream
			ExcelFile.close();

			//Create an object of FileOutputStream class to create write data in excel file
			FileOutputStream outputStream = new FileOutputStream(file);

			//write data in the excel file
			ExcelWBook.write(outputStream);

			//close output stream
			outputStream.close();

		}

	}
//end of write




}
