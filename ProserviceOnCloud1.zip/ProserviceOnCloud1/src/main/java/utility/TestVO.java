package utility;

public class TestVO {
//rms_id, ra_id, ext_instance_no
	private String rmsID;
	private String raID;
	private String extInstanceNo;
	public static String databaseValue;
	
	public String getDatabaseValue() {
		return databaseValue;
	}
	public String setDatabaseValue(String databaseValue) {
		this.databaseValue = databaseValue;
		return databaseValue;
	}
	
	public String getRmsID() {
		return rmsID;
	}
	public void setRmsID(String rmsID) {
		this.rmsID = rmsID;
	}
	
	public String getRaID() {
		return raID;
	}
	public void setRaID(String raID) {
		this.raID = raID;
	}
	
	public String getExtInstanceNo() {
		return extInstanceNo;
	}
	public void setExtInstanceNo(String extInstanceNo) {
		this.extInstanceNo = extInstanceNo;
	}
	
	
	
	
}
