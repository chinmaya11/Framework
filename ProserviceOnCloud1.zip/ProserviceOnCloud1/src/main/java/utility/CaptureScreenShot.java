package utility;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.Test;

import Config.ActionKeywords;
import Config.Constants;
import executionEngine.DriverScript;

public class CaptureScreenShot {
	
	//public static WebDriver driver;
	//private static final TakesScreenshot Driver = null;
	
	public static TakesScreenshot ts;
	public static TakesScreenshot cs;
	public static String fileExtnSC = ".png";
	public static String screenShotName;
	public static String screenShotNameExtent;
	public static long dateFormat;
	public static ITestResult result;
	
	
	public static void takeScreenShot(WebDriver driver) throws Exception {
		
		try {
			/*System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\src\\main\\resources\\lib\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			
			driver.get("http://www.facebook.com/");
			driver.findElement(By.xpath(".//*[@id='email']")).sendKeys("Chinmaya");*/
			
			/*if (ITestResult.SUCCESS==result.getStatus()) {
				dateFormat = new Date().getTime();       
				 System.out.println("Current Date time is :- "+dateFormat);			
				 screenShotName=DriverScript.sTestCaseModuleID+"_"+DriverScript.sTestCaseID+"_"+DriverScript.sTestScenarioSteps+"_"+DriverScript.sTestScenarioStepsDescription+"_"+dateFormat+fileExtnSC;
				
				//TakesScreenshot TS=(TakesScreenshot)ActionKeywords.driver;
				ts=(TakesScreenshot)driver;
				File sourceFile = ts.getScreenshotAs(OutputType.FILE);		
				FileUtils.copyFile(sourceFile, new File("./ScreenShot/"+screenShotName));		
				System.out.println("Screenshot captured");
			}
			else if (ITestResult.FAILURE==result.getStatus()) {
				dateFormat = new Date().getTime();       
				 System.out.println("Current Date time is :- "+dateFormat);			
				 screenShotName=DriverScript.sTestCaseModuleID+"_"+DriverScript.sTestCaseID+"_"+DriverScript.sTestScenarioSteps+"_"+DriverScript.sTestScenarioStepsDescription+"_"+dateFormat+fileExtnSC;
				
				//TakesScreenshot TS=(TakesScreenshot)ActionKeywords.driver;
				ts=(TakesScreenshot)driver;
				File sourceFile = ts.getScreenshotAs(OutputType.FILE);		
				FileUtils.copyFile(sourceFile, new File("./ScreenShot/"+screenShotName));		
				System.out.println("Screenshot captured");
			}
			else if (ITestResult.SKIP==result.getStatus()) {
				dateFormat = new Date().getTime();       
				 System.out.println("Current Date time is :- "+dateFormat);			
				 screenShotName=DriverScript.sTestCaseModuleID+"_"+DriverScript.sTestCaseID+"_"+DriverScript.sTestScenarioSteps+"_"+DriverScript.sTestScenarioStepsDescription+"_"+dateFormat+fileExtnSC;
				
				//TakesScreenshot TS=(TakesScreenshot)ActionKeywords.driver;
				ts=(TakesScreenshot)driver;
				File sourceFile = ts.getScreenshotAs(OutputType.FILE);		
				FileUtils.copyFile(sourceFile, new File("./ScreenShot/"+screenShotName));		
				System.out.println("Screenshot captured");;
			}*/
			
			
			 dateFormat = new Date().getTime();       
			 System.out.println("Current Date time is :- "+dateFormat);			
			 screenShotName="FAIL_"+DriverScript.sTestCaseModuleID+"_"+DriverScript.sTestCaseID+"_"+DriverScript.sTestScenarioSteps+"_"+DriverScript.sTestScenarioStepsDescription+"_"+dateFormat+fileExtnSC;
			
			//TakesScreenshot TS=(TakesScreenshot)ActionKeywords.driver;
			ts=(TakesScreenshot)driver;
			File sourceFile = ts.getScreenshotAs(OutputType.FILE);		
			FileUtils.copyFile(sourceFile, new File("./ScreenShot/"+screenShotName));		
			System.out.println("Screenshot captured");
			
		} catch (Exception e) {
			System.out.println("Exception while taking screen shot :-"+e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	public static String captureScreen(WebDriver driver, String screenShotName) throws Exception {
		try {
		dateFormat = new Date().getTime();       
		System.out.println("Current Date time is :- "+dateFormat);			
		screenShotNameExtent="FAIL_"+DriverScript.sTestCaseModuleID+"_"+DriverScript.sTestCaseID+"_"+DriverScript.sTestScenarioSteps+"_"+DriverScript.sTestScenarioStepsDescription+"_"+dateFormat+fileExtnSC;
		
		cs=(TakesScreenshot)driver;
		File sourceFolder=cs.getScreenshotAs(OutputType.FILE);
		String destFolder=System.getProperty("user.dir")+"/ExtentReportScreenShot/"+screenShotNameExtent;
		
		File destination=new File(destFolder);
		FileUtils.copyFile(sourceFolder, destination);
		System.out.println("Screenshot captured For Extent Report");
		return destFolder;
		
		} catch (Exception e) {
			System.out.println("Exception while taking screen shot For Extent Report :-"+e.getMessage());
			e.printStackTrace();
			return null;
		}
		
	}
	
	
}
