package utility;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import executionEngine.DriverScript;
import Config.ActionKeywords;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class JDBCConnection {
	public static final String URL = "jdbc:postgresql://10.101.5.154:5433/rms";
	public static final String UserName = "rms";
	public static final String Password = "rmslt01";
	
	public static final String URLOracle = "jdbc:oracle:thin:@localhost:1521:xe";
	public static final String UserNameOracle = "rms";
	public static final String PasswordOracle = "rmslt01";

	public static Connection conn;
	public static PreparedStatement stmt;

	public static void getDbConnection(String object, String data) throws Exception, ClassNotFoundException, SQLException {

		try {
			System.out.println("JDBC Connection In-Progress!!!");
			//Get a connection to database
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection(URL,UserName,Password);

			//Create a Statement
			//Statement myStmt = conn.createStatement();
			System.out.println("JDBC Connection Done!!!");
			PreparedStatement stmt = conn.prepareStatement(object);
			ResultSet rs = stmt.executeQuery();

			//Process the result set
			System.out.println("Connection extablished!!!");
			List<TestVO> list=new ArrayList<TestVO>();
			while (rs.next()) {
				TestVO testVO = new TestVO();
				System.out.println("Success FULL 1");
				String databasevalue=testVO.setDatabaseValue(rs.getString(1));
				assertTrue(databasevalue.contains(data));
				System.out.println("Database value retrive from database is :- "+databasevalue);
				System.out.println("UI value retrive from UI is :- "+data);
				System.out.println("Success FULL 2");
				
				/*testVO.setRmsID(rs.getString(1));
				testVO.setRaID(rs.getString(2));
				testVO.setExtInstanceNo(rs.getString(3));
				System.out.println("Database Query values : "+rs.getString(1)+"---"+rs.getString(2)+"---"+rs.getString(3));*/
				list.add(testVO);

			}
			System.out.println("Database values are (LIST) : "+list);

		} 
		catch(Exception e) {
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
			e.printStackTrace();
		}
	}

	private static void assertTrue(boolean contains) {
		// TODO Auto-generated method stub
		
	}

	public static PreparedStatement getStatement() throws ClassNotFoundException, SQLException  {

		try {
			System.out.println("JDBC connection test 1");
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection(URL,UserName,Password);
			stmt = (PreparedStatement) conn.createStatement();
			return stmt;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stmt;
	}

	public void insertData(String query) throws ClassNotFoundException, SQLException{
		Statement sta = getStatement();
		sta.executeUpdate(query);
	}

	public ResultSet getData(String query) throws ClassNotFoundException, SQLException{
		ResultSet data = getStatement().executeQuery(query);
		return data;
	}

	public ResultSet updateData(String query) throws ClassNotFoundException, SQLException{
		ResultSet data = getStatement().executeQuery(query);
		return data;
	}



	//new code and class
	public static Connection getPostGressDbConn() throws ClassNotFoundException, SQLException {

		System.out.println("JDBC connection test 1");
		Class.forName("org.postgresql.Driver");
		Connection myConn = DriverManager.getConnection(URL,UserName,Password);

		System.out.println("JDBC connection test 2");
		if(myConn != null) {
			System.out.println("Connection extablished!!!");
			PreparedStatement stmt = myConn.prepareStatement("select * from postgres.rms_instrument");
			ResultSet Rs = stmt.executeQuery();
			while (Rs.next()) {
				System.out.println(Rs.getString(1)+" "+Rs.getString(2));
			}
			return myConn;
		}

		return null;
	}

}
