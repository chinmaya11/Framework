package executionEngine;

import java.io.FileInputStream;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import utility.ExcelUtils;
import utility.Log;
import utility.JDBCConnection;
import utility.CaptureScreenShot;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import Config.ActionKeywords;
import Config.Constants;

public class DriverScript {

    
	public static Method method[];
    public static String sAction = null;
    public static String sObject = null;
    public static String sData = null;
    public static Properties OR;
    public static Properties CONFIG;

    public static int iTestStep;
    public static int iTestCases;
    public static int iTestLastStep;
    public static String sTestCaseID;
    public static String sTestCaseIDModule;
    public static String sDescription;
    public static String sDescriptionModule;
    public static String sRunMode;
    public static String sRunModeModule;
    public static String Col_TestStepDesc;
    public static String testPass="PASS";
    public static String testFail="FAIL";

    public static String sTestCaseStepID;
    public static String sTestCaseModuleID;
    public static String  sTestScenarioSteps;
    public static String  sTestScenarioStepsDescription;

    public static int iTotalTestCasesModules;
    public static String fileExtn = ".xlsx";
    public static int iTotalTestCases;
    public static int rows;
    public static int i;
    public static int j;
    public static int k;
    public static int l;
    public static String item;
    public static String sModuleName;
    
    public static ExtentReports extent;
    public static ExtentTest test;
    public static ITestResult result;
    
    

    
    public static final String filePath = System.getProperty("user.dir") + "ExtentReport.html";

    static {
        Calendar calender = Calendar.getInstance();
        SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
        extent = new ExtentReports(System.getProperty("user.dir") + "/src/main/resources/resultEngine/test" + formater.format(calender.getTime()) + ".html", false);
    }

    public static void getResult(ITestResult result)  throws Exception {
    	try {
        if (result.getStatus() == ITestResult.SUCCESS) {
            test.log(LogStatus.PASS, result.getName() + " - Test is pass");
        } else if (result.getStatus() == ITestResult.SKIP) {
            test.log(LogStatus.SKIP, result.getName() + " - Test is skipped and skip reason is :-" + result.getThrowable());
        } else if (result.getStatus() == ITestResult.FAILURE) {
        	//String screenShotPath=CaptureScreenShot.captureScreen(ActionKeywords.driver, "screenShotExtentReport");
            //test.log(LogStatus.ERROR, result.getName() + " - Test error :-" + result.getThrowable());
            test.log(LogStatus.FAIL, result.getName() + " - Test failed :-" + result.getThrowable());
            //test.log(LogStatus.FAIL, "Screen Shot Below : " +test.addScreenCapture(screenShotPath));
        } else if (result.getStatus() == ITestResult.STARTED) {
            test.log(LogStatus.INFO, result.getName() + " - Test is started");
        } 
    	}
    	catch (Exception e) {
			System.out.println("Exception while capturing Result :-"+e.getMessage());
			e.printStackTrace();
		}
    }

    @AfterMethod()
    public void afterMethod(ITestResult result) throws Exception {
        getResult(result);
        //extent.endTest(test);
    }    

    /*@BeforeMethod()
    public void beforeMethod(Method result) {
        test = extent.startTest(result.getName());
        test.log(LogStatus.INFO, result.getName() + "test started");
    }*/

    @AfterClass(alwaysRun = true)
    public void endTest() {
    	test.log(LogStatus.INFO, " Test Execution Ended ");
        extent.endTest(test);
        extent.flush();
        //extent.close();
    }
    
    /*@BeforeSuite
    public void beforeSuite() {
        extent = ExtentManager.getReporter(filePath);
    }*/
    
   /* @AfterSuite
    protected void afterSuite() {
        extent.close();
    }
*/
/* @AfterTest
    protected void afterSuite() {
        extent.close();
    }*/
    
    //for testcasename and testcase description
    public static void beforeMethodTestname(String testCaseName, String testCaseDescription) {
        //test = extent.startTest(testCaseName);
        test = extent.startTest(testCaseName, testCaseDescription);
        test.log(LogStatus.INFO, testCaseName + " Test Execution Started ");
    }

    public DriverScript() {
    }

    //public static void main(String[] args) throws Exception {
    @Test
    public static void startTestSuite() throws Exception{

        DOMConfigurator.configure("log4j.xml");

        System.out.println("<<<----------------Automation Test Suite Run Started!!!---------------->>>");
        Log.info("<<<----------------Automation Test Suite Run Started!!!---------------->>>");

        FileInputStream fis = new FileInputStream(Constants.Path_OR);
        OR = new Properties(System.getProperties());
        OR.load(fis);

        FileInputStream fis2 = new FileInputStream(Constants.Path_CONFIG);
        CONFIG = new Properties(System.getProperties());
        CONFIG.load(fis2);

        String TestSuite = Constants.Path_TestDataModule;
        ExcelUtils.setExcelFile(TestSuite);
        System.out.println("Test Suite path is :- " + TestSuite);
        Log.info("Test Suite path is :- " + TestSuite);

        iTotalTestCasesModules = ExcelUtils.getRowCount(Constants.Sheet_TestCasesModules);
        System.out.println("Total Test Modules Exist In Test suite :- " + (iTotalTestCasesModules - 1));
        Log.info("Total Test Modules Exist In Test suite :- " + (iTotalTestCasesModules - 1));

        ArrayList<String> sheetModuleData = new ArrayList<String>();

        for (l = 1; l < iTotalTestCasesModules; l++) {
            //System.out.println("L value is : " + l + " and iTotalTestCasesModules is :" + iTotalTestCasesModules);
            Log.info("L value is : " + l + " and iTotalTestCasesModules is :" + iTotalTestCasesModules);
            Log.info("Step Executing Times : " + l);

            String TestSuite1 = Constants.Path_TestDataModule;
            ExcelUtils.setExcelFile(TestSuite1);

            sModuleName = ExcelUtils.getCellData(l, Constants.Col_TestCaseIDModule, Constants.Sheet_TestCasesModules);
            sRunModeModule = ExcelUtils.getCellData(l, Constants.Col_RunmodeModule, Constants.Sheet_TestCasesModules);
            sTestCaseIDModule = ExcelUtils.getCellData(l, Constants.Col_TestCaseIDModule, Constants.Sheet_TestCasesModules);
            System.out.println("Module Name: = " + sModuleName);
            System.out.println("Module Run?: = " + sRunModeModule);
            Log.info("Module Name: = " + sModuleName);
            Log.info("Module Run?: = " + sRunModeModule);
            
            ExcelUtils objExcelFile = new ExcelUtils();
            String sPath = (Constants.Path_TestData1) + sModuleName + fileExtn;
            RunModule(sPath);
        }
        
        //Print ArrayList to Excel
        ExcelUtils objExcelFile = new ExcelUtils();
        for(String s: ActionKeywords.valueToWriteToExcel)
        {
        	System.out.println(s);
        	System.out.println("-----------------------------------Writting Test Result To Excel----------------------------------------");
        	Log.info("-----------------------------------Writting Test Result To Excel----------------------------------------");
        	String[] valueToWriteToExcel = s.split(",");
        	objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        }
        
		/*for (String item : sheetModuleData) {
			System.out.println("Module Name "+l+ " : " +item);
			String sPath=(Constants.Path_TestData1)+item+fileExtn;
			RunModule(sPath);
			}*/
        
    } 
    //end of main

       
    public static void RunModule(String modulePath) throws Exception {

        System.out.println("Run Module Start for module_id : "+sModuleName);
        Log.info("Run Module Start for module_id : "+sModuleName);

        if (modulePath != null) 
        {
            System.out.println("Path is : " + modulePath);
                        
                if (sRunModeModule.equalsIgnoreCase("yes") && sModuleName.equals(sTestCaseIDModule)) {
                	
                	
                	
                    //String datafile = Constants.Path_TestData;
                    ExcelUtils.setExcelFile(modulePath);
                    
                  

                    iTestCases = ExcelUtils.getRowContains(sTestCaseIDModule, Constants.Col_TestCaseIDModule, Constants.Sheet_TestCases);
                    System.out.println("iTestCases value is : " + iTestCases);
                    Log.info("iTestCases value is : " + iTestCases);

                    iTotalTestCases = ExcelUtils.getRowCount(Constants.Sheet_TestCases);
                    
                    System.out.println("Total Number Of Test Cases : " + (iTotalTestCases - 1));
                    System.out.println("Executing Test Module_ID : " + sTestCaseIDModule);
                    System.out.println("Test Module Description : " + sDescriptionModule);
                    Log.info("Total Number Of Test Cases : " + (iTotalTestCases - 1));
                    Log.info("Executing Test Module_ID : " + sTestCaseIDModule);
                    Log.info("Test Module Description : " + sDescriptionModule);

                    for (j = iTestCases; j < iTotalTestCases; j++) {
                        sTestCaseModuleID = ExcelUtils.getCellData(j, Constants.Col_TestCaseIDModule, Constants.Sheet_TestCases);
                        sRunMode = ExcelUtils.getCellData(j, Constants.Col_Runmode, Constants.Sheet_TestCases);
                        sDescription = ExcelUtils.getCellData(j, Constants.Col_TestCaseDesc, Constants.Sheet_TestCases);
                        if (sTestCaseModuleID.equals(sTestCaseIDModule) && sRunMode.equalsIgnoreCase("yes")) {
                            sTestCaseID = ExcelUtils.getCellData(j, Constants.Col_TestCaseID, Constants.Sheet_TestCases);
                            
                            //generating report
                            beforeMethodTestname(sTestCaseID, sDescription);
                            //beforeMethodTestname(sTestCaseID);
                            
                            System.out.println("Executing Test CaseID : " + sTestCaseID);
                            System.out.println("Test CaseID Description : " + sDescription);
                            Log.info("Executing Test CaseID : " + sTestCaseID);
                            Log.info("Test CaseID Description : " + sDescription);
                            Log.info("Automation Started For Test Cases Testcases_ID :- " + sTestCaseID);

                            iTestStep = ExcelUtils.getRowContains(sTestCaseID, Constants.Col_TestCaseID, Constants.Sheet_TestSteps);
                            System.out.println("iTestStep value is : " + iTestStep);
                            Log.info("iTestStep value is : " + iTestStep);

                            rows = ExcelUtils.getRowCount(Constants.Sheet_TestSteps);
                            
                            System.out.println("Total Number Of Rows = " + rows);
                            Log.info("Total Number Of Rows = " + rows);
                            Log.info("Automation Test Step Run Started For Testcases_ID :" + sTestCaseID);

                            for (i = iTestStep; i <= rows; i++) {
                            	System.out.println("<<<<<<<<=========" + i + "=========>>>>>>>>");
                            	Log.info("=========" + i + "=========" + Constants.Col_TestCaseID);
                            	Log.info("=========" + sTestCaseID + "=====" + ExcelUtils.getCellData(i, Constants.Col_TestCaseID, Constants.Sheet_TestSteps));
                                if (sTestCaseID.equals(ExcelUtils.getCellData(i, Constants.Col_TestCaseID, Constants.Sheet_TestSteps))) {
                                    sTestCaseStepID = ExcelUtils.getCellData(i, Constants.Col_TestCaseID, Constants.Sheet_TestSteps);
                                    sTestScenarioSteps= ExcelUtils.getCellData(i, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps);
                                    sTestScenarioStepsDescription= ExcelUtils.getCellData(i, Constants.Col_TestStepDesc, Constants.Sheet_TestSteps);
                                    
                                    System.out.println("Executing Row = " + i);
                                    System.out.println("Executing Test Case ID :" + sTestCaseStepID);
                                    System.out.println("Executing Test Scenario Step ID :" + ExcelUtils.getCellData(i, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps));
                                    System.out.println("Executing Test Scenario Description :" + "'" + ExcelUtils.getCellData(i, Constants.Col_TestStepDesc, Constants.Sheet_TestSteps) + "'");
                                    
                                    Log.info("Executing Row = " + i);
                                    Log.info("Executing Test Case ID :" + sTestCaseStepID);
                                    Log.info("Executing Test Scenario Step ID :" + ExcelUtils.getCellData(i, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps));
                                    Log.info("Executing Test Scenario Description :" + "'" + ExcelUtils.getCellData(i, Constants.Col_TestStepDesc, Constants.Sheet_TestSteps) + "'");
                                    
                                    //logging data into extent report
                                    //test.log(LogStatus.INFO, sTestScenarioSteps + "-"+sTestScenarioStepsDescription+ " - Test Step");
                                    
                                    sAction = ExcelUtils.getCellData(i, Constants.Col_ActionKeyword, Constants.Sheet_TestSteps);
                                    sObject = ExcelUtils.getCellData(i, Constants.Col_ObjectKeyword, Constants.Sheet_TestSteps);
                                    sData = ExcelUtils.getCellData(i, Constants.Col_DataKeyword, Constants.Sheet_TestSteps);
                                    
                                    
                                    
                                    execute_actions();
                                    //CaptureScreenShot.takeScreenShot();
                                }                                    
                                 else {
                                    System.out.println("Automation Test Step Run Ended For Testcases_ID :" + sTestCaseStepID + " Successfully");
                                    Log.info("Automation Test Step Run Ended For Testcases_ID :" + sTestCaseStepID);
                                    break;
                                	
                                	/*String testPass="PASS";
                                	System.out.println("Automation Test Step Run Ended For Testcases_ID :" + sTestCaseStepID + " Successfully");
                                    Log.info("Automation Test Step Run Ended For Testcases_ID :" + sTestCaseStepID);
                                    Log.info("Module_ID is "+sTestCaseIDModule+" and "+"Testcases " + sTestCaseStepID+" PASS ");
                                    System.out.println("Module_ID is "+sTestCaseIDModule+" and "+"Testcases " + sTestCaseStepID+" PASS ");
                                    String[] valueToWriteToExcel = {sTestCaseIDModule, sTestCaseID, sTestScenarioSteps, testPass};
                                    //sTestCaseIDModule or sTestCaseModuleID
                                    //Create an object of current class
                                    ExcelUtils objExcelFile = new ExcelUtils();
                                    //Write the file using file name, sheet name and the data to be filled
                                    objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
                                    break;*/                                   
                                }
                                 
                            }
                            
                        } else if (sRunMode.equalsIgnoreCase("no")) {
                            System.out.println("Automation Test Cases Run Ended For Testcases_ID :" + sTestCaseID + " Successfully");
                            Log.info("Automation Test Cases Run Ended For Testcases_ID :" + sTestCaseID);
                            
                            
                            
                            //write code for complete testcase                            
                            //break; //do not uncomment need to check later
                        }
                    }
                    
                } else if(sRunModeModule.equalsIgnoreCase("no") ) {
                    System.out.println("Automation Run Ended!!!");
                    Log.info("Automation Run Ended Successfully!!!");
                    
                    /*test.log(LogStatus.INFO, sTestCaseID + "<---Test Execution Ended Finally--->");
                    extent.endTest(test);*/
                    //break; //do not uncomment need to check later
                }
            }
        }   

    public void afterMethod1(ITestResult result) throws Exception {
        getResult(result);
    }
    
    
    public static void execute_actions() throws Exception {

        if (sAction.equals("open")) { 	
        	ActionKeywords.open(sObject, sData);
        	//CaptureScreenShot.takeScreenShot();
            Log.info("Opening browser : " + sData);
        } else if (sAction.equals("selectBrowser")) {
            ActionKeywords.selectBrowser(sObject, sData);
            Log.info("Select and Open browser : " + sData);
        } else if (sAction.equals("openBrowser")) {
            ActionKeywords.openBrowser(sObject, sData);
            Log.info("Open browser : " + sData);
        } else if (sAction.equals("navigate")) {
            ActionKeywords.navigate(sObject, sData);
            Log.info("Launching URl : " + sData);
            //test.log(LogStatus.INFO, sAction + " Executing steps"); 
            //test.log(LogStatus.INFO, sTestScenarioSteps + " Executing steps");
        } else if (sAction.equals("click")) {
            ActionKeywords.click(sObject, sData);
            Log.info("Clicking on Object :" + sObject);
        } else if (sAction.equals("type")) {
            ActionKeywords.type(sObject, sData);
            Log.info("Typeing Data into input fields :" + sObject + " and data : " + sData);
        } else if (sAction.equals("waitFor")) {
            ActionKeywords.waitFor(sObject, sData);
            Log.info("Wait for :" + sData + " sec ");
        } else if (sAction.equals("close")) {
            ActionKeywords.close(sObject, sData);
            Log.info("Closing Browser" + sData);
        } else if (sAction.equals("quit")) {
            ActionKeywords.quit(sObject, sData);
            Log.info("Closing All Windows");
        } else if (sAction.equals("openIEBrowser")) {
            ActionKeywords.openIEBrowser(sObject, sData);
        } else if (sAction.equals("selectDropDown")) {
            ActionKeywords.selectDropDown(sObject, sData);
            Log.info("Select From Dropdown : " + sObject + " and data : " + sData);
        } else if (sAction.equals("enterData")) {
            ActionKeywords.enterData(sObject, sData);
            Log.info("Entering Data into input fields :" + sObject + " and data : " + sData);
        } else if (sAction.equals("selectCheckBox")) {
            ActionKeywords.selectCheckBox(sObject, sData);
            Log.info("Selecting check Box fields :" + sObject);
        } else if (sAction.equals("popUpAccept")) {
            ActionKeywords.popUpAccept(sObject, sData);
            Log.info("Handling Pop-up Accept");
        } else if (sAction.equals("popUpDismiss")) {
            ActionKeywords.popUpDismiss(sObject, sData);
            Log.info("Handling Pop-up Dismiss");
        } else if (sAction.equals("DatabaseConn")) {
            ActionKeywords.DatabaseConn(sObject, sData);
            Log.info("Connecting Database");
        } else if (sAction.equals("getInnerText")) {
            ActionKeywords.getInnerText(sObject, sData);
            Log.info("Verifying Text");
        } else if (sAction.equals("verifyTextPresent")) {
            ActionKeywords.verifyTextPresent(sObject, sData);
            Log.info("Verifying Text");
        } else if (sAction.equals("verifyDBData")) {
            ActionKeywords.verifyDBData(sObject, sData);
            Log.info("Verifying Text");
        } else if (sAction.equals("clear")) {
            ActionKeywords.clear(sObject, sData);
            Log.info("clearing Text");
        } else if (sAction.equals("checkElementPresent")) {
            ActionKeywords.checkElementPresent(sObject, sData);
            Log.info("checking element present in the DOM");
        } else if (sAction.equals("checkElementVisible")) {
            ActionKeywords.checkElementVisible(sObject, sData);
            Log.info("checking element visible in the DOM");
        } else if (sAction.equals("checkElementEnable")) {
            ActionKeywords.checkElementEnable(sObject, sData);
            Log.info("checking element enable in the DOM");
        } else if (sAction.equals("verifyOracleDBData")) {
            ActionKeywords.verifyOracleDBData(sObject, sData);
            Log.info("checking element enable in the DOM");
        } else if (sAction.equals("delete")) {
            ActionKeywords.delete(sObject, sData);
            Log.info("checking element enable in the DOM");
        } else if (sAction.equals("toolTips")) {
            ActionKeywords.toolTips(sObject, sData);
            Log.info("checking element enable in the DOM");
        } else if (sAction.equals("isTextPresent")) {
            ActionKeywords.verifyTextNotPresent(sObject, sData);
            Log.info("checking element enable in the DOM");
        } else if (sAction.equals("isElementPresentinTable")) {
            ActionKeywords.isElementPresentinTable(sObject, sData);
            Log.info("checking element enable in the DOM");
        } else if (sAction.equals("enableCheckBox")) {
            ActionKeywords.enableCheckBox(sObject, sData);
            Log.info("checking element enable in the DOM");
        }
    }
    
  //For JDBC connection verifyGetText
    //JDBCConnection.getDbConnection();
    //JDBCConnection.getPostGressDbConn();

    /*TestReport();
    String[] valueToWrite = {"Mr. E", "Noida"};
    //Create an object of current class
    ExcelUtils objExcelFile = new ExcelUtils();
    //Write the file using file name, sheet name and the data to be filled
    objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWrite);*/
    
    
  //Required later for reporting part
    /*public static void TestReport() throws Exception{
		Xl.generateReport("Constants.Path_TestData1","report.xlsx");
		System.out.println("Test Report");
	}*/

}
//End Of Class
