package Config;

public class Constants {

	public static final String URL = "https://proservicedp-dev.dxone.beckmancoulter.com/dashboard?instanceid=8746672";
	public static final String Path_TestData = System.getProperty("user.dir") + "\\src\\main\\resources\\dataEngine\\DataEngine.xlsx";
	public static final String Path_TestData1 = System.getProperty("user.dir") + "\\src\\main\\resources\\dataEngine\\";
	public static final String Path_TestDataModule = System.getProperty("user.dir") + "\\src\\main\\resources\\dataEngine\\TestSuite.xlsx";
	

	//write excel
	public static final String Path_TestReports = System.getProperty("user.dir") + "\\src\\main\\resources\\dataEngine\\TestReport.xlsx";
	public static final String Path_TestReports1 = System.getProperty("user.dir") + "\\src\\main\\resources\\dataEngine\\";
	public static final String fileName1 = "TestReport.xlsx";
	public static final String Sheet_TestReports = "Test Reports";
	
	public static final String Path_OR = System.getProperty("user.dir") + "\\src\\main\\resources\\configEngine\\OR.txt";
	public static final String Path_CONFIG = System.getProperty("user.dir") + "\\src\\main\\resources\\configEngine\\config.txt";
	public static final String File_TestData = "DataEngine.xlsx";
	
	//new code
	public static final String Sheet_TestCasesModules = "Test Cases Modules";
	
	//public static final String Sheet_TestCasesModules = "Test Modules";
	public static final String Sheet_TestCases = "Test Cases";
	public static final String Sheet_TestSteps = "Test Steps";
	
	//For My Test Only
	public static final String filePath = System.getProperty("user.dir") + "\\dataEngine\\DataEngine.xlsx";
	public static final String fileName = "DataEngine.xlsx";
	public static final String sheetName = "Test Steps";
	
	//List of Data Sheet Column Numbers
	//For Module sheet Test modules Sheet
	public static final int Col_TestCaseIDModule = 0;	
	public static final int Col_TestModuleDesc =1;
	public static final int Col_RunmodeModule =2;
	
	//For Test Cases sheet	
	//public static final int Col_TestCasesModuleID = 0;
	public static final int Col_TestCaseID = 1;	
	public static final int Col_TestCaseDesc = 2;
	public static final int Col_Runmode =3;
	
	//For Test Steps Sheet
	public static final int Col_TestScenarioID =2 ;
	public static final int Col_TestStepDesc =3;
	public static final int Col_ActionKeyword =4;
	public static final int Col_ObjectKeyword =5;
	public static final int Col_DataKeyword =6;	
	
	
	

	
	//Database Login and Verification
	public static final String DB1 = "select distinct rms_id, ra_id, ext_instance_no from rms.rms_instrument limit 5";
	
	
	
	
}
 
	//List of Data Engine Excel sheets
	
 
	
