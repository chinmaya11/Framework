package Config;

import executionEngine.DriverScript;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import Config.Constants;


import java.util.ArrayList;

import utility.CaptureScreenShot;
import utility.ExcelUtils;
import utility.JDBCConnection;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import com.google.common.base.Function;
import com.relevantcodes.extentreports.LogStatus;

import utility.Log;
import utility.TestVO;

import static executionEngine.DriverScript.OR;
import static executionEngine.DriverScript.CONFIG;

public class ActionKeywords {

	private static ITestResult result;
	public static WebDriver driver;
	public static Properties Repository = new Properties();
	public static ArrayList<String> valueToWriteToExcel = new ArrayList<String>();
	public static Object firstHandle;
	public static Object lastHandle;
	public static ExcelUtils objExcelFile = new ExcelUtils();
	public static String[] valueToWriteToExcel_test = null;
	
	public static Connection conn;
	public static PreparedStatement stmt;
	public static SoftAssert assertion;
	
	public static String celtext;
	public static Iterator itr;
	public static  List list;
	
	
	
//	public static void switchToWindowsPopup() {
//	    Set<String> handles = DriverManager.getCurrent().getWindowHandles();
//	    Iterator<String> itr = handles.iterator();
//	    firstHandle = itr.next();
//	    lastHandle = firstHandle;
//	    while (itr.hasNext()) {
//	        lastHandle = itr.next();
//	    }
//	    DriverManager.getCurrent().switchTo().window(lastHandle.toString());
//	}
//
//	public static void switchToMainWindow() {
//	    DriverManager.getCurrent().switchTo().window(firstHandle.toString());
	
	
	/*public static void impliciteWait(String data) throws Exception{
		Reporter.log("waiting for page to load...");
		try{
		driver.manage().timeouts().implicitlyWait(Long.parseLong(data), TimeUnit.SECONDS);
		Reporter.log("Page is loaded");
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
		}
		catch(Throwable e){
			Reporter.log("Timeout for Page Load Request to complete after "+ data + " seconds");
			Assert.assertTrue(false, "Timeout for page load request after "+data+" second");
				CaptureScreenShot.takeScreenShot(driver);
				valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
		        ExcelUtils objExcelFile = new ExcelUtils();
		        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
		        e.printStackTrace();
			}
	}*/
	
	
	
	public static void expliciteWait_bkp(WebElement element, int timeToWaitInSec) {
		WebDriverWait wait = new WebDriverWait(driver, timeToWaitInSec);
		wait.withTimeout(60, TimeUnit.SECONDS);
		wait.pollingEvery(60, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.visibilityOf(element));
		wait.until(ExpectedConditions.textToBePresentInElement(element, "text"));
	}
	
	public static void expliciteWait(String object, String data) throws Exception {
		try
		{
				WebDriverWait wait = new WebDriverWait(driver, Integer.parseInt(data));
				wait.until(ExpectedConditions.visibilityOf(getWebElement(object)));
				//CaptureScreenShot.takeScreenShot(driver);
				valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
				System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
				Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
		        ExcelUtils objExcelFile = new ExcelUtils();
		        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
		        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
				}
				catch(Exception e)
				{
					CaptureScreenShot.takeScreenShot(driver);
					valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
					System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
					Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
					String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
			        ExcelUtils objExcelFile = new ExcelUtils();
			        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
			        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
			        Log.info("Got an exception!!! : "+e.getMessage());
			        Log.error(e);
			        e.printStackTrace();
				}
	}
	
	
	
	
	public static void fluentWait(String object, String data) throws Exception {
		//Create object of FluentWait class and pass webdriver as input

	       Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
	       .withTimeout(120, TimeUnit.SECONDS)
	       .pollingEvery(5, TimeUnit.SECONDS)
	       .ignoring(NoSuchElementException.class);

	       //wait.withTimeout(60, TimeUnit.SECONDS);
	       //wait.pollingEvery(5, TimeUnit.SECONDS);       
	       
	       // we are creating Function here which accept webdriver and output as WebElement-  // apply method- which accept webdriver as input      
	       // @Override
	       WebElement element = wait.until(new Function<WebDriver, WebElement>() 
	       				{    	   
						public WebElement apply(WebDriver driver, String object, String data) throws Exception 
						{
						    WebElement ele = getWebElement(object);						    
						    String value = ele.getAttribute("innerHTML");
						
						//Will capture the inner Text and will compare will WebDriver
						//If condition is true then it will return the element and wait will be over
						                  if (value.equalsIgnoreCase(data)) 
						                   {					
						                       System.out.println("Value is >>> " + ele.getAttribute("innerHTML"));
						                       DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
						                       return ele;
						                  }
												else {
												     System.out.println("Value is >>> " + ele.getAttribute("innerHTML"));
												     DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
												        return null;
												    }
												  }

											public WebElement apply(WebDriver driver) {
												DriverScript.test.log(LogStatus.INFO, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - INFO PASS");
												return null;
											}
									});

	//If element is found then it will display the status
	       System.out.println("Final visible status is >>>>> " + element.isDisplayed());
	}
	


	public static void open(String object, String data){
		try
		{
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\src\\main\\resources\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//impliciteWait(10);
		//impliciteWait(data);
		driver.manage().window().maximize();
		
		//sTestScenarioStepsDescription
		
		
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
		}
	}

	public static void openIEBrowser(String object, String data){
		try
		{
		System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "\\src\\main\\resources\\lib\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//impliciteWait(10);
		//impliciteWait(data);
		driver.manage().window().maximize();
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + "PASS");
	    //String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testPass};
         //sTestCaseIDModule or sTestCaseModuleID
         //Create an object of current class
           ExcelUtils objExcelFile = new ExcelUtils();
           System.out.println("HELLLLLLLLLLLLLLLLLLOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOo");
           //Write the file using file name, sheet name and the data to be filled
           ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
           DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");    
		}
		catch(Exception e)
		{
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestCaseStepID + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestCaseStepID + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestCaseStepID + "," + "FAIL");
			DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
		}
		
	}

	public static void openBrowser(String object, String data) throws Exception{
		try
		{
			if (data.equals("ie") || data.equals("IE")) {
				System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "\\src\\main\\resources\\lib\\IEDriverServer.exe");
				
				DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
				caps.setCapability("ignoreZoomSetting", true);
				driver = new InternetExplorerDriver(caps);

				
				//driver = new InternetExplorerDriver();
				driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
				driver.manage().timeouts().setScriptTimeout(40, TimeUnit.SECONDS);				
				//impliciteWait(10);
				//impliciteWait(data);
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();				
				//DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");				
			} else if (data.equals("chrome") || data.equals("CHROME")) {
				System.out.println("chrome browser");
				System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\main\\resources\\lib\\chromedriver.exe");
				driver = new ChromeDriver();
				driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
				driver.manage().timeouts().setScriptTimeout(40, TimeUnit.SECONDS);
				//impliciteWait(10);
				//impliciteWait(data);
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();
				//DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
			} else if (data.equals("firefox") || data.equals("FIREFOX")) {
				System.out.println("firefox browser");
				//System.setProperty("webdriver.firefox.driver",System.getProperty("user.dir")+ "\\src\\main\\com\\actiTime\\BrowserDrivers\\chromedriver.exe");
				driver = new FirefoxDriver();
				driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
				driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
				driver.manage().timeouts().setScriptTimeout(40, TimeUnit.SECONDS);
				//impliciteWait(10);
				//impliciteWait(data);
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();
				//DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
			}
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    //valueToWriteToExcel_test[0] = DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        //ExcelUtils.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
		DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			//String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
			DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        e.printStackTrace();
	        //Log.error(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
	        Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        throw(e);
		}		
	}

	public static WebDriver selectBrowser(String object, String data) throws Exception{
		try
		{
		if (data.equals("firefox") || data.equals("FIREFOX")) {
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			return driver;
		} else if (data.equals("chrome") || data.equals("CHROME")) {
			System.out.println("chrome browser");
			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+ "\\src\\main\\resources\\lib\\IEDriverServer.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			return driver;
		} else if (data.equals("ie") || data.equals("IE")) {
			driver = new InternetExplorerDriver();
			driver.manage().window().maximize();
			return driver;
		}
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        e.printStackTrace();
		}
		
		return null;
	}

	public static void popUpAccept(String object, String data) throws Exception{
		try
		{
//			if (data.equalsIgnoreCase("ok")) {
			System.out.println("Trying Deleting the user group...");
			Log.info("Trying Deleting the user group...");
			Thread.sleep(10000);
			Alert myAlert = driver.switchTo().alert();
			myAlert.accept();
			/*} 
			else if  (data.equalsIgnoreCase("cancel")) {
				Alert myAlert = driver.switchTo().alert();
				myAlert.dismiss();		
			}*/		
		
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
		}
	}

	
	public static void popUpDismiss(String object, String data) throws Exception{
		try
		{
//			
			System.out.println("Trying Deleting the user group...");
			Log.info("Trying Deleting the user group...");
			Thread.sleep(10000);
			Alert myAlert = driver.switchTo().alert();
			myAlert.dismiss();	
		
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
		}
	}
	
	
	
	public static void navigate(String object, String data) throws Exception{
		try
		{
		driver.get(CONFIG.getProperty(data));
		//CaptureScreenShot.takeSConCondition(driver, null);
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    //afterMethod11(result);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			//afterMethod11(result);
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
			DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
			Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
		}
	}

	private static void afterMethod11(ITestResult result) throws Exception {
		DriverScript.getResult(result);
		
	}



	public static void click(String object, String data) throws Exception
	{
		try
		{
			//new code
			/*WebDriverWait wait=new WebDriverWait(driver, 20);
			WebElement elementForClick;
			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(object));
			elementForClick.click();
			*/
			
		getWebElement(object).click();		
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
		}
		

		//driver.findElement(By.xpath(OR.getProperty(object))).click();
	}

	public static void selectDropDown(String object, String data) throws Exception
	{
		try
		{
						
		Log.info("Drop down for instrument model selected Process strted");
		Select dropDownIM=new Select(getWebElement(object));
		//dropDownIM.selectByVisibleText(CONFIG.getProperty(data));
		dropDownIM.selectByVisibleText(data);
		Log.info("Drop down for instrument model selected successfully");

//getWebElement(object).click();
//driver.findElement(By.xpath(OR.getProperty(object))).click();
//WebElement selectElement=getWebElement(object);
//		Select dropDownIM = new Select(driver.findElement(By.xpath("//div[@class='inputs-block']/select[@data-reactid='.0.2.0.2.2.0.2']")));
//		dropDownIM.selectByVisibleText("ACCESS2");
		
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
		}
	}

	public static void type(String object, String data) throws Exception
	{
		try
		{
		getWebElement(object).sendKeys(CONFIG.getProperty(data));
		//driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(CONFIG.getProperty(data));
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ExcelUtils objExcelFile = new ExcelUtils();
		String imagePath="C:\\Frameworks\\ProserviceOnCloud1\\ExtentReportScreenShot\\test.png";
		////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        //DriverScript.test.addScreenCapture(imagePath);
        //DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS", imagePath);
        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        String imagePath="C:\\Frameworks\\ProserviceOnCloud1\\ExtentReportScreenShot\\image1.jpg";
	        //DriverScript.test.addScreenCapture(imagePath);
	        //DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL", imagePath);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        e.printStackTrace();
	        Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
		}
	}

	//need to implement code for sendkeys generic
	public static void enterData(String object, String data) throws Exception
	{
		try
		{
			getWebElement(object).sendKeys(data);
		
		//driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(CONFIG.getProperty(data));
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        Log.info("Got an exception!!! : "+e.getMessage());
	        e.printStackTrace();
		}
	}

	public static void waitFor(String object, String data) throws Exception
	{
		int x = Integer.parseInt(data);
		long time = x * 1000;
		try {
			Thread.sleep(time);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.INFO, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
			}
			catch(Exception e)
			{
				CaptureScreenShot.takeScreenShot(driver);
				valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
		        ExcelUtils objExcelFile = new ExcelUtils();
		        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
		        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
		        e.printStackTrace();
			}
	}
	//Checkbox functionality
	public static void selectCheckBox(String object, String data) throws Exception {
		try{
		//getWebElement(object).click();
		if(!getWebElement(object).isSelected()) {
			getWebElement(object).click();
			
		}
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        e.printStackTrace();
		}

	}


	public static void close(String object, String data) throws Exception
	{
		try
		{
		driver.close();
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			//driver.switchTo().window(base);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
			DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        e.printStackTrace();
		}
	}


	public static void quit(String object, String data) throws Exception
	{
		try
		{
		driver.quit();
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
			DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        e.printStackTrace();
		}
	}


	public static void DatabaseConn(String object, String data) throws Exception
	{
		try {
		JDBCConnection.getDbConnection(OR.getProperty(object),data);		
		
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
			DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        e.printStackTrace();
		}
	}
	
	public static void verifyDBData(String object, String data) throws Exception {
		try {
			assertion = new SoftAssert();
			
			System.out.println("JDBC Connection In-Progress!!!");
			Log.info("JDBC Connection In-Progress!!!");
			//JDBCConnection.getDbConnection(OR.getProperty(object),data);
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection(JDBCConnection.URL,JDBCConnection.UserName,JDBCConnection.Password);
			System.out.println("JDBC Connection Done!!!");
			Log.info("JDBC Connection Done!!!");
			PreparedStatement stmt = conn.prepareStatement(OR.getProperty(object));
			ResultSet rs = stmt.executeQuery();
			
			List<TestVO> list=new ArrayList<TestVO>();
			
			while (rs.next()) {
				TestVO testVO = new TestVO();
				String databasevalue=testVO.setDatabaseValue(rs.getString(1));
				assertion.assertTrue(true);
				assertion.assertEquals(databasevalue, data, "ActaulDB Data Result & ExpectedDB Data Result are not matched");	
				//if (databasevalue.equals(data)) {
				System.out.println("Database value retrive from database is :- "+databasevalue);
				System.out.println("UI value retrive from UI is :- "+data);
				list.add(testVO);
				//}
			}
			System.out.println("Database values are (LIST) : "+list);			
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
	        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
		    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		    //Code to close each and all Object related to Database connection		
		    if (rs != null) {
				try {
					rs.close();
					System.out.println("Closing all database resultset");
					Log.info("Closing all database resultset");
				} catch (Exception e) {
				}
		    }
		    if (stmt != null) {
				try {
					stmt.close();
					System.out.println("Closing all database statement");
					Log.info("Closing all database statement");
				} catch (Exception e) {
				}
			}
		    if(conn!=null) {
				//conn=null;
				conn.close();
				System.out.println("Closing all database connection");
				Log.info("Closing all database connection");
		    }
		    assertion.assertAll();
			}
			catch(AssertionError e)
			{
				valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
		        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
				DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
		        e.printStackTrace();
		        //Log.info("Message : "+e);
		        Log.info("Got an exception!!! : "+e.getMessage());
		        Log.error(e);
			}		
	}
	
	
	
	
	public static void verifyOracleDBData(String object, String data) {
		try {
			assertion = new SoftAssert();
			
			System.out.println("ORACLE JDBC Connection In-Progress!!!");
			Log.info("ORACLE JDBC Connection In-Progress!!!");
			//JDBCConnection.getDbConnection(OR.getProperty(object),data);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection(JDBCConnection.URL,JDBCConnection.UserName,JDBCConnection.Password);
			System.out.println("JDBC Connection Done!!!");
			Log.info("JDBC Connection Done!!!");
			PreparedStatement stmt = conn.prepareStatement(OR.getProperty(object));
			ResultSet rs = stmt.executeQuery();
			
			List<TestVO> list=new ArrayList<TestVO>();
			
			while (rs.next()) {
				TestVO testVO = new TestVO();
				System.out.println("Success FULL 3");
				String databasevalue=testVO.setDatabaseValue(rs.getString(1));
				assertion.assertEquals(databasevalue, data, "ActaulDB Data Result & ExpectedDB Data Result are not matched");	
				//if (databasevalue.equals(data)) {
				System.out.println("Database value retrive from database is :- "+databasevalue);
				System.out.println("UI value retrive from UI is :- "+data);
				System.out.println("Success FULL 4");
				list.add(testVO);
				//}
			}
			System.out.println("Database values are (LIST) : "+list);			
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
	        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
		    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		    assertion.assertAll();
			}
			catch(Exception e)
			{
				valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
		        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
				DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
		        e.printStackTrace();
			}
		
	}
	
	


/*	public static WebElement getWebElement(String object) throws Exception{
		return getLocators(OR.getProperty(object));
	}*/
	
	public static WebElement getWebElement(String object) throws Exception{
		try {
			return getLocators(OR.getProperty(object));
		}
		catch (Exception e) {
			e.printStackTrace();
			Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
			return null;
		}
		
		
	}
	
	public static void verifyTextPresent(String object, String data) throws Exception {
		try
		{
		String actualText = getWebElement(object).getText();
		//String actualText1 = getWebElement(object).getAttribute("innerHTML");
		//String actualText = getWebElement(object).getText().toString();
		
		System.out.println("checking getText method Actual Text:- "+actualText);
		System.out.println("checking getText method Expected Test:- "+data);
		
		//Working code for verifying text in different ways - hard assertion
		//boolean pageSource=driver.getPageSource().contains(data);		
		//Assert.assertTrue(actualText.contains(data), "Actauls & Expecteds are not matched");
		//Assert.assertEquals(actualText, data, "Actaul & Expected are not matched");	
		
		//Soft assert implementation
		assertion = new SoftAssert();
		assertion.assertTrue(true);
		assertion.assertEquals(actualText, data, "ActaulText Result & ExpectedText Resulr are not matched");
		//assertion.assertEquals(actualText, data);
		assertion.assertAll();
		
		
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
	    //assertion.assertAll();
		}
		catch(AssertionError e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
			DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
			Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
		}
	}
	
	
	
	public static void verifyPartialTextPresent(String object, String data) throws Exception {
		try
		{
		String actualText = getWebElement(object).getText();
		System.out.println("checking getText method :- "+actualText);
		System.out.println("checking getText method :- "+data);
		
		//Hard assert implementation
		//Assert.assertEquals(actualText, data, "Actaul & Expected are not matched");	
		
		//Soft assert implementation
		assertion = new SoftAssert();
		assertion.assertTrue(true);
		assertion.assertTrue(actualText.contains(data), "Actauls & Expecteds are not matched");	
		
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
	    assertion.assertAll();
		}
		catch(AssertionError e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
			DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
			Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
		}
	}
	
	
	
	public static boolean isTextPresents(String object){
	    try{
	        boolean b = driver.getPageSource().contains(object);
	        //DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
	        return b;
	    }
	    catch(Exception e){
	    	//DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	    	e.printStackTrace();
	    	Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        return false;
	    }
	  }
	
	public static void getInnerText(String object, String data) throws Exception {
		try
		{
		//String textContent = getWebElement(object).getText();
		String textContent = getWebElement(object).getAttribute("value");
		//Assert.assertTrue(textContent.contains(data));
		//assertTrue(isTextPresents(data));
		System.out.println("checking getText method :- "+textContent);
		System.out.println("checking getText method :- "+data);
		assertion = new SoftAssert();
		assertion.assertTrue(true);
		assertion.assertEquals(textContent, data, "ActaulText Result & ExpectedText Resulr are not matched");
		//assertion.assertEquals(actualText, data);
		assertion.assertAll();
		
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(AssertionError e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
			DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
			Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
		}
	}
	
	

	private static void assertTrue(boolean textPresent) {
		
	}

	public static WebElement getLocators(String object) throws Exception {
		String[] split = object.split(":");
		String locatorType = split[0];
		String locatorValue = split[1];

		if (locatorType.toLowerCase().equals("id"))
			return driver.findElement(By.id(locatorValue));
		else if (locatorType.toLowerCase().equals("name"))
			return driver.findElement(By.name(locatorValue));
		else if ((locatorType.toLowerCase().equals("classname"))
				|| (locatorType.toLowerCase().equals("class")))
			return driver.findElement(By.className(locatorValue));
		else if ((locatorType.toLowerCase().equals("tagname"))
				|| (locatorType.toLowerCase().equals("tag")))
			return driver.findElement(By.tagName(locatorValue));
		else if ((locatorType.toLowerCase().equals("linktext"))
				|| (locatorType.toLowerCase().equals("link")))
			return driver.findElement(By.linkText(locatorValue));
		else if (locatorType.toLowerCase().equals("partiallinktext"))
			return driver.findElement(By.partialLinkText(locatorValue));
		else if ((locatorType.toLowerCase().equals("cssselector"))
				|| (locatorType.toLowerCase().equals("css")))
			return driver.findElement(By.cssSelector(locatorValue));
		else if (locatorType.toLowerCase().equals("xpath"))
			return driver.findElement(By.xpath(locatorValue));
		else
			throw new Exception("Unknown locator type '" + locatorType + "'");
	}



	public static void clear(String object, String data) throws Exception
	{
		try
		{
		getWebElement(object).clear();
		
		//CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
		}
	}



	public static boolean  checkElementPresent(String object, String data) throws Exception {
		try {
			//WebElement eleCheck = getWebElement(object);
			
			if(getWebElement(object)!= null){
				System.out.println("Element is Present");
				Log.info("Element is Present");
				}else{
				System.out.println("Element is Absent");
				Log.info("Element is Absent");
				}
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		}
		catch(Exception e)
		{
			CaptureScreenShot.takeScreenShot(driver);
			valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
			String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
	        ExcelUtils objExcelFile = new ExcelUtils();
	        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
	        Log.info("Got an exception!!! : "+e.getMessage());
	        Log.error(e);
	        e.printStackTrace();
	        return false;
		}
		return true;
		
	}



	public static boolean checkElementVisible(String object, String data) throws Exception {
		
		try {			
				if(getWebElement(object).isDisplayed()){
					System.out.println("Element is Visible");
					Log.info("Element is Visible");
				} else
				{
				System.out.println("Element is InVisible");
				Log.info("Element is InVisible");
				}
				valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
				System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
				Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
		        ExcelUtils objExcelFile = new ExcelUtils();
		        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
			}
			catch(Exception e)
			{
				CaptureScreenShot.takeScreenShot(driver);
				valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
		        ExcelUtils objExcelFile = new ExcelUtils();
		        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
		        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
		        Log.info("Got an exception!!! : "+e.getMessage());
		        Log.error(e);
		        e.printStackTrace();
		        return false;
			}
			return true;
		
	}



	public static boolean checkElementEnable(String object, String data) throws Exception {
		try {			
				if(getWebElement(object).isEnabled()){
					System.out.println("Element is Enable");
					Log.info("Element is Enable");
				} else
				{
				System.out.println("Element is Disabled");
				Log.info("Element is Disabled");
				}
				valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
				System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
				Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
			    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
		        ExcelUtils objExcelFile = new ExcelUtils();
		        DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
			}
			catch(Exception e)
			{
				CaptureScreenShot.takeScreenShot(driver);
				valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
				String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
		        ExcelUtils objExcelFile = new ExcelUtils();
		        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
		        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
		        Log.info("Got an exception!!! : "+e.getMessage());
		        Log.error(e);
		        e.printStackTrace();
		        return false;
			}
			return true;
		
	}
	
public static void captureScreenShots(WebDriver ldriver){
 
  // Take screenshot and store as a file format
  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
try {
  // now copy the  screenshot to desired location using copyFile method
 
 FileUtils.copyFile(src, new File("C:/selenium/"+System.currentTimeMillis()+".png"));
       }
 
catch (IOException e)
 
{
 
System.out.println(e.getMessage());
Log.info("Got an exception!!! : "+e.getMessage());
Log.error(e);
 
    }
 
}

public static void delete(String Object, String Data) throws Exception {
	try{
		//getWebElement(Object).sendKeys(Keys.CONTROL,"a",Keys.DELETE);
		getWebElement(Object).sendKeys(Keys.CONTROL,"a");
		getWebElement(Object).sendKeys(Keys.DELETE);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
	    ExcelUtils objExcelFile = new ExcelUtils();
	    ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
	} catch(Exception e)
	{
		CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
        Log.info("Got an exception!!! : "+e.getMessage());
        Log.error(e);
        e.printStackTrace();
	}
	
	
}

public static void isElementPresentinTable(String object, String data) throws Exception{
    try{
    assertion = new SoftAssert();
    list = new ArrayList();
    
    
    //To locate table.
    WebElement searchTable = getWebElement(object);
    //List list = new ArrayList();
    //To locate rows of table.
    List<WebElement> rows_table = searchTable.findElements(By.tagName("tr"));
    System.out.println("Table values are :"+rows_table);
    //To calculate no of rows In table.
    int rowcount = rows_table.size();
    System.out.println("Table rows count : "+rowcount);
    
  //Loop will execute till the last row of table.
    for (int i = 0; i<rowcount; i++ ){
    	//To locate columns(cells) of that specific row.
    	List<WebElement> Columns_row = rows_table.get(i).findElements(By.tagName("td"));
    	//To calculate no of columns(cells) In that specific row.
    	int columns_count = Columns_row.size();
    	System.out.println("Number of cells In Row "+i+" are "+columns_count);
    			//Loop will execute till the last cell of that specific row.
		    	for (int j=0; j<columns_count; j++){
		    		//To retrieve text from that specific cell.
		    	    celtext = Columns_row.get(j).getText();
		    	    System.out.println("--------------------------------------------------"); 
		    	    System.out.println("Cell Value Of row number "+i+" and column number "+j+" Is "+celtext);
		    	    Log.info("Cell Value Of row number "+i+" and column number "+j+" Is "+celtext);
		    	    list.add(celtext);
		    	    /*if (celtext.equalsIgnoreCase(data)){
		    	    	break;
		    	    }*/
		    	     
		    	}
		    	   System.out.println("==================================================");    	
				   /*String actualtext = rows_table.get(i).getText();
		           assertion.assertTrue(true);
		           assertion.assertEquals(actualtext, data, "ActaulText Result & ExpectedText Resulr are not matched");
		           assertion.assertAll();  */
		           System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++");  
    			}
    			/*itr = list.iterator();
    			    while (itr.hasNext()){   
    				System.out.println("While loop started");
					    if (celtext.equalsIgnoreCase(data)){
						    assertion.assertTrue(true);
						    assertion.assertEquals(celtext, data, "ActaulText Result & ExpectedText Result are not matched");
						    assertion.assertAll(); 
						    System.out.println("HURRY TEST PASSED");
						    break;
						    }
    			}*/
    System.out.println("list values are : "+list);
    /*itr = list.iterator();
    while (itr.hasNext()){   
		System.out.println("While loop started");
		    if (celtext.equalsIgnoreCase(data)){
			    break;
			    }
	}*/
    if (list.contains(data)) {
    	System.out.println("Data Matched");
    } else {
    	System.out.println("Data Not matched");
    	assertion.assertTrue(false);
	    assertion.assertEquals(celtext, data, "ActaulText Result & ExpectedText Result are not matched");
	    assertion.assertAll(); 
    }
    }
    catch (AssertionError e) {
      CaptureScreenShot.takeScreenShot(driver);
      valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
      System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
      Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
      String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
      ExcelUtils objExcelFile = new ExcelUtils();
      //objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
      DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
      Log.info("Got an exception!!! : "+e.getMessage());
      Log.error(e);
      e.printStackTrace();
    }
           
    }

public static void toolTips(String object, String data) throws Exception {
	try{
		//Soft assert implementation
		assertion = new SoftAssert();			
		Actions builder=new Actions(driver);
		WebElement tooltip_Text=getWebElement(object);
		builder.moveToElement(tooltip_Text).perform();
		String tooltip_msg=tooltip_Text.getText();
		//String tooltip_msgs=tooltip_Text.getAttribute("title");
		System.out.println("Tooltip message is "+tooltip_msg);
		//System.out.println("Tooltip messages are "+tooltip_msgs);
		assertion.assertTrue(true);
		assertion.assertEquals(tooltip_msg, data, "ActaulText Result & ExpectedText Resulr are not matched");
		System.out.println("Tooltip Message verifed");
		assertion.assertAll();		
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
	    ExcelUtils objExcelFile = new ExcelUtils();
	    ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
	} catch(AssertionError e)
	{
		CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
        Log.info("Got an exception!!! : "+e.getMessage());
        Log.error(e);
        e.printStackTrace();
	}
}

public static void verifyTextNotPresent(String object, String data) throws Exception {
	try{
		//Soft assert implementation
		//String aText= false;
		assertion = new SoftAssert();			
		boolean b = driver.getPageSource().contains(data);
		System.out.println("Return value is : "+b+" and data is :"+data);
		assertion.assertTrue(true);
	    assertion.assertEquals(false, b, "Text '"+data+"' is present in the page, hence test failed");
	    assertion.assertAll(); 
		/*if (b==false) {
			System.out.println("Text '"+data+"' is not present in the page");
			assertion.assertTrue(false);
		    assertion.assertEquals(false, b, "Text '"+data+"' is not present in the page");
		    assertion.assertAll(); 
		} else {
			assertion.assertTrue(false);
		    assertion.assertEquals(true, b, "Text '"+data+"' is present in the page");
		    assertion.assertAll(); 
		}*/
		
        //DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
	    ExcelUtils objExcelFile = new ExcelUtils();
	    ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
	} catch(AssertionError e)
	{
		CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
        Log.info("Got an exception!!! : "+e.getMessage());
        Log.error(e);
        e.printStackTrace();
	}
	//return false;
	
}

public static void enableCheckBox(String object, String data) throws Exception {
	try{
		boolean bValue = false;
		bValue=getWebElement(object).isSelected();
		System.out.println("check box value is : "+bValue);
		if(bValue == false) {
			System.out.println("Check box is enabled now");
			getWebElement(object).click();			
		}		
        //DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "PASS");
	    String[] valueToWriteToExcel = {DriverScript.sTestCaseModuleID, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.sTestScenarioStepsDescription, DriverScript.testPass};
	    ExcelUtils objExcelFile = new ExcelUtils();
	    ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
	    DriverScript.test.log(LogStatus.PASS, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - PASS");
	} catch(Exception e)
	{
		CaptureScreenShot.takeScreenShot(driver);
		valueToWriteToExcel.add(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		System.out.println(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		Log.info(DriverScript.sTestCaseModuleID + "," + DriverScript.sTestCaseID + "," + DriverScript.sTestScenarioSteps + "," + DriverScript.sTestScenarioStepsDescription + "," + "FAIL");
		String[] valueToWriteToExcel = {DriverScript.sTestCaseIDModule, DriverScript.sTestCaseID, DriverScript.sTestScenarioSteps, DriverScript.testFail};
        ExcelUtils objExcelFile = new ExcelUtils();
        ////objExcelFile.writeExcel((Constants.Path_TestReports1), (Constants.fileName1), (Constants.Sheet_TestReports), valueToWriteToExcel);
        DriverScript.test.log(LogStatus.FAIL, DriverScript.sTestScenarioSteps + "-"+DriverScript.sTestScenarioStepsDescription+ " - FAIL");
        Log.info("Got an exception!!! : "+e.getMessage());
        Log.error(e);
        e.printStackTrace();
	}
	
	
}


}
